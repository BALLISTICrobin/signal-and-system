from a2105046 import *

def main():
    # Input for first polynomial
    # Input for first polynomial
    

    # Stock Market Prices as a Python List
    price_list = list(map(int, input("Stock Prices: ").split()))
    n = int(input("Window size: "))

    # price_list = [1, 2, 3, 4, 5, 6, 7, 8]
    # n = 4

    impulse_signal = DiscreteSignal(len(price_list))

    for i in range(len(price_list)):
        impulse_signal.set_value_at_time(i, price_list[i])
    
    input_signal_uw = DiscreteSignal(len(price_list))

    for i in range(n):
        input_signal_uw.set_value_at_time(i, 1/n)
    
    input_signal_w = DiscreteSignal(len(price_list))

    weights = np.zeros(n)
    for i in range(n):
        weights[i] = (n-i)/((n*(n+1))/2)



    for i in range(n):
        input_signal_w.set_value_at_time(i, weights[i])


    print(impulse_signal.values)
    print(input_signal_uw.values)
    print(input_signal_w.values)

    lti_system = LTI_Discrete(input_signal_uw)

    uma, a = lti_system.output(impulse_signal)

    lti_system = LTI_Discrete(input_signal_w)
    wma, a = lti_system.output(impulse_signal)

    # Please determine uma and wma.

    # Unweighted Moving Averages as a Python list
    uma = uma.values[input_signal_uw.INF + n -1: -1]

    # Weighted Moving Averages as a Python list
    wma = wma.values[input_signal_w.INF + n -1: -1]

    #  Print the two moving averages
    print("Unweighted Moving Averages: " + ", ".join(f"{num:.2f}" for num in uma))
    print("Weighted Moving Averages:   " + ", ".join(f"{num:.2f}" for num in wma))



main()